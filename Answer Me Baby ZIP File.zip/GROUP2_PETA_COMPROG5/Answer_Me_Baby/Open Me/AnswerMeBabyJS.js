function open(){
    window.location.href = "../AMB-LogIn/index.html";
}