function startTimer() {
    var seconds = 15;

    var countdown = setInterval(function() {
      seconds--;

      if(seconds==14){
        document.getElementById("percentage").innerHTML = "20%";
        var una = document.getElementById('una');
        una.style.backgroundColor = 'green'; 
      }
      if(seconds==12){
        document.getElementById("percentage").innerHTML = "40%";
        var two = document.getElementById('two');
        two.style.backgroundColor = 'green'; 
      }
      if(seconds==9){
        document.getElementById("percentage").innerHTML = "60%";
        var tatlo = document.getElementById('tatlo');
        tatlo.style.backgroundColor = 'green'; 
      }
      if(seconds==6){
        document.getElementById("percentage").innerHTML = "80%";
        var por = document.getElementById('por');
        por.style.backgroundColor = 'green'; 
      }
      if(seconds==3){
        document.getElementById("percentage").innerHTML = "99%";
        var five = document.getElementById('five');
        five.style.backgroundColor = 'green'; 
      }
      if (seconds <= 0) {
        clearInterval(countdown);
        window.location.href = '../AMB-Welcome/Play.html';
      }
    }, 1000); //1k milli = 1sec
  }

  window.onload = startTimer;