let questions = [
  {
    question: "What country started the World War 2?",
    options: ["Great Britain", "USA", "Germany", "Soviet Union"],
    correctAnswer: "Germany"
  }, //1
  {
    question: "Who is the first president of the Philippines?",
    options: ["Andres Bonifacio", "Jose Rizal", "Emilio Aguinaldo", "Ferdinand Marcos"],
    correctAnswer: "Emilio Aguinaldo"
  }, //2
  {
    question: "What is the largest organ in the human body?",
    options: ["Liver", "Brain", "Kidney", "Skin"],
    correctAnswer: "Skin"
  }, //3
  {
    question: "What is the chemical symbol for water?",
    options: ["CO2", "H2O", "GU", "UA"],
    correctAnswer: "H2O"
  }, //4
  {
    question: "Who is the God of Muslim Religion?",
    options: ["Jesus Christ", "Allah", "Joseph", "Jehovah"],
    correctAnswer: "Allah"
  }, //5
  {
    question: "In which ancient civilization was the Great Pyramid of Giza built?",
    options: ["Mesopotamia", "Ancient Rome", "Ancient Greece", "Ancient Egypt"],
    correctAnswer: "Ancient Egypt"
  }, //6
  {
    question: "What is the ancient empire who invaded almost all of the europe?",
    options: ["Ottoman Empire", "Mongol Empire", "British Empire", "Roman Empire"],
    correctAnswer: "Roman Empire"
  }, //7
  {
    question: "What is the sum of the interior angles of a triangle?",
    options: ["90 degrees", "180 degrees", "270 degrees", "360 degrees"],
    correctAnswer: "180 degrees"
  }, //8
  {
    question: "Which event marked the beginning of World War II?",
    options: ["Treaty of Versailles", "The invasion of Poland", "The bombing of Pearl Harbor", "The Battle of Stalingrad"],
    correctAnswer: "The invasion of Poland"
  },
  {
    question: "Who was the painter of Mona Lisa?",
    options: ["Leonardo Da Vinci", "Leonardo DiCarpio", "Vincent Van Gogh", "Juan Luna"],
    correctAnswer: "Leonardo Da Vinci"
  },
  {
    question: "Who is the painter of Spolarium?",
    options: ["EraserHeads", "Juan Luna", "Antonio Luna", "Vincent Van Gough"],
    correctAnswer: "Juan Luna"
  },
  {
    question: "Who formulated the gravitational theory",
    options: ["Isaac Newton", "Charles Darwin", "Albert Einstein", "Galileo Galilei"],
    correctAnswer: "Isaac Newton"
  },
  {
    question: "What is the known theory of the origin of the universe?",
    options: ["Plama Universe Theory", "Quantum Fluctuation Theory", "Bigbang Theory", "Oscillating Universe Theory"],
    correctAnswer: "Bigbang Theory"
  },
  {
    question: "Who is the father of science?",
    options: ["Isaac Newton", "Charles Darwin", "Albert Einstein", "Galileo Galilei"],
    correctAnswer: "Isaac Newton"
  },
  {
    question: "How many elements are there in the periodic table?",
    options: ["118", "119", "'122", "110"],
    correctAnswer: "118"
  },
  {
    question: "Which element has the chemical symbol of H",
    options: ["Helium", "Hydrogen", "Iron", "Sodium"],
    correctAnswer: "Hydrogen"
  },
  {
    question: "What is the unit of measurement for electric current?",
    options: ["Ohm", "Volt", "Ampere", "Watt"],
    correctAnswer: "Ampere"
  },
  {
    question: "What is the closest galaxy to the Milky Way?",
    options: ["Triangulum", "Sombrero", "Whirlpool", "Andromeda"],
    correctAnswer: "Andromeda"
  },
  {
    question: "What is the powerhouse of the cell",
    options: ["Nucleus", "Mitochondria", "Ribosome", "Endoplasmic Reticulum"],
    correctAnswer: "Mitochondria"
  },
  {
    question: "What is the name of this symbol ()?",
    options: ["Parentheses", "Exponent", "Equation", "Denominator"],
    correctAnswer: "Parentheses"
  },
  {
    question: "what is the sqaure root of 64",
    options: ["6", "8", "7", "9"],
    correctAnswer: "8"
  },
  {
    question: "What is 5 squared?",
    options: ["20", "30", "25", "40"],
    correctAnswer: "25"
  },
  {
    question: "Which is the only number that cannot be used as a Divisor?",
    options: ["-1", "0", "10", "1"],
    correctAnswer: "0"
  },
  {
    question: "Which is number system does not have the symbol for zero?",
    options: ["Roman Numerals", "Binary Numbers", "Hexadecimal Numbers", "Decimal Numbers"],
    correctAnswer: "Roman Numerals"
  },
  {
    question: "What comes after a trillion?",
    options: ["Septillion", "Quintillion", "Sextillion", "Quadrillion"],
    correctAnswer: "Quadrillion"
  },
  {
    question: "What is the name for the longest side of a Right Angled Triangle?",
    options: ["Base", "Hypotenuse", "Adjacent", "Opposite"],
    correctAnswer: "Hypotenuse"
  },
  {
    question: "Mathematical device that has Beads?",
    options: ["Napier's Bones", "Astrolobe", "Abacus", "Quipu"],
    correctAnswer: "Abacus"
  },
  {
    question: "How many Zeros are there in One Billion?",
    options: ["8", "10", "7", "9"],
    correctAnswer: "9"
  },
  {
    question: "Name of the Symbol ∑?",
    options: ["Sigma", "Mean", "Variance", "Summation"],
    correctAnswer: "Summation"
  },
  {
    question: "When did RMS Titanic sink",
    options: ["1911", "1912", "1910", "1909"],
    correctAnswer: "1912"
  }
];

let currentQuestion = 0;
let score = 0;
let timer;
let timerInterval;

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function initializeQuiz() {
  shuffle(questions);
  displayQuestion();
  startTimer();
  timerInterval = setInterval(updateTimer, 1000);
}

function startTimer() {
  timer = setTimeout(() => {
    alert("Time's up!");
    nextQuestion();
  }, 20000);
}

function resetTimer() {
  clearTimeout(timer);
  const timerElement = document.querySelector('.secstimer');
  timerElement.textContent = "20"; 
  startTimer();
}


function updateTimer() {
  const timerElement = document.querySelector('.secstimer');
  let seconds = parseInt(timerElement.textContent);
  if (seconds > 0) {
    seconds--;
    timerElement.textContent = seconds;
  }
}

function displayQuestion() {
  const questionElement = document.getElementById("question");
  const optionsElement = document.getElementById("options");

  questionElement.textContent = questions[currentQuestion].question;

  optionsElement.innerHTML = "";
  questions[currentQuestion].options.forEach((option) => {
    const button = document.createElement("button");
    button.textContent = option;
    button.classList.add("quiz-button");

    button.addEventListener("click", () => {
      checkAnswer(option);
      resetTimer();
    });
    
    optionsElement.appendChild(button);
  });
}


function checkAnswer(selectedAnswer) {
  const correctAnswer = questions[currentQuestion].correctAnswer;

  if (selectedAnswer === correctAnswer) {
    score++;
  } else{
    alert("Your answer is incorrect, correct answers will be shown once you finish this quiz");
  }

  document.getElementById("score").textContent = `Score: ${score}`;
  nextQuestion();
}

function openFile() {
  window.open('../../Trivias/Easy-Trivia (1)/Trivia.html', '_blank');
}


function nextQuestion() {
  currentQuestion++;

  if (currentQuestion < questions.length) {
    displayQuestion();
    resetTimer();
  } else {
    clearInterval(timerInterval);
    clearTimeout(timer);
    alert(`Quiz completed! Your final score is ${score}`);
    openFile();
    
  }
}