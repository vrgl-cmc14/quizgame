let questions = [
  {
    question: "What year did World War 2 begin?",
    options: ["1938", "1939", "1940", "1945"],
    correctAnswer: "1939"
  },
  {
    question: "What is six (6) squared?",
    options: ["12", "24", "30", "36"],
    correctAnswer: "36"
  },
  {
    question: "Which 3 numbers have the same answer whether they're added or multiplied together?",
    options: ["3, 2 and 1", "1, 6 and 1", "1, 2 and 3", "3, 1 and 1"],
    correctAnswer: "1, 2 and 3" && "3, 2 and 1"
  },
  {
    question: "Who was the first president of the United States of America?",
    options: ["Denzel Washington", "George Washington", "Bush Washington", "Chris Washington"],
    correctAnswer: "George Washington"
  },
  {
    question: "the science of structure, order, and relation that has evolved from elemental practices of counting, measuring, and more.",
    options: ["Mathematics", "Physics", "Chemistry", "Alchemy"],
    correctAnswer: "Mathematics"
  },
  {
    question: "Who painted the famous artwork 'The Starry Night'?",
    options: ["Salvador Dalí", "Pablo Picasso", "Vincent van Gogh", "Claude Monet"],
    correctAnswer: "Vincent van Gogh"
  },
  {
    question: "Who invented the telephone?",
    options: ["Thomas  Bell", "Alexander Graham Bell", "Thelma Bell", "Leonardo Bell"],
    correctAnswer: "Alexander Graham Bell"
  },
  {
    question: "The Olympic Games are held every _______ years.",
    options: ["four", "three", "five", "six"],
    correctAnswer: "four"
  },
  {
    question: "The highest mountain range in the world is the ________.",
    options: ["Pinalayas", "Himalayas", "Timalayas", "Himalay"],
    correctAnswer: "Himalayas"
  },
  {
    question: "The famous painting 'The Last Supper' was created by ________.",
    options: ["Leonardo da Vinci", "Vincent van gogh", "pablo picasso", "Leonard  De Vince"],
    correctAnswer: "Leonardo da Vinci"
  },
  {
    question: "What is the largest artery in the human body?",
    options: ["Arterioles", "Artery", "Aorta", "Heart"],
    correctAnswer: "Aorta"
  },
  {
    question: "What was the first book published in the Philippines?",
    options: ["Doctrina Christiana", "Doctrina Kristiano", "El Doctrino y Amigo", "Trinidad Doctora"],
    correctAnswer: "Doctrina Christiana"
  },
  {
    question: "She was the first woman member of the Katipunan (July 1893)",
    options: ["melchora aquino", "trinidad tecson", "Gregoria de Jesús", "teodora alonso"],
    correctAnswer: "Gregoria de Jesús"
  },
  {
    question: "One of the last Filipino generals who fought the Americans and established the so-called 'Tagalog Republic'",
    options: ["gregoria del pilar", "andres bonifacio", "antonio luna", "Macario Sakay"],
    correctAnswer: "Macario Sakay"
  },
  {
    question: "Who was the first Filipino recording artist?",
    options: ["Maria Carpena", "maria Calipto", "maria cerena", "maria lourdes ignacio"],
    correctAnswer: "Maria Carpena"
  },
  {
    question: "Which fruit is red and has seeds outside?",
    options: ["berry", "Strawberry", "potentilla indica", "berrys oseed"],
    correctAnswer: "Strawberry"
  },
  {
    question: "What do bees collect from flowers?",
    options: ["pollen", "stamens", "pistil", "Nectar"],
    correctAnswer: "Nectar"
  },
  {
    question: "What do you use to cut paper in a straight line?",
    options: ["Scissors", "Cutter", "Architech Scissors", "Rotary Scissors"],
    correctAnswer: "Scissors"
  },
  {
    question: "Which bird is known for its wisdom in stories?",
    options: ["Owl", "parrot", "hornbill", "Eagle"],
    correctAnswer: "Owl"
  },
  {
    question: "What is the shape of a circle?",
    options: ["cylinder", "Round", "sphere", "cone"],
    correctAnswer: "Round"
  },
  {
    question: "What do you call a group of fish?",
    options: ["School", "Highschool", "Elementary", "Academy"],
    correctAnswer: "School"
  },
  {
    question: "The whistleblower behind the NSA surveillance  revelations",
    options: ["Mark Whitacre", "Edward Snowden", "Daniel Midland", "Peter Buxton"],
    correctAnswer: "Edward Snowden"
  },
  {
    question: "Who is known as the father of computer?",
    options: ["Dennis ritchie", "Bill gates", "Charles babbage", "James gosling"],
    correctAnswer: "Charles babbage"
  },
  {
    question: "Which of the following is the smallest unit of memory?",
    options: ["byte", "kb", "nibble", "bit"],
    correctAnswer: "bit"
  },
  {
    question: "Which are the Surnames of people in the 1000 peso bill in the following.",
    options: ["Santos, Escoda, Lim", "Laurel, Osmena, Klara De jesus", "Abad, Alverillo, Lim", "Abad, Alverillo, Osmena"],
    correctAnswer: "Santos, Escoda, Lim"
  },
  {
    question: "Which planet is known as the “Blue Planet”?",
    options: ["Uranus", "Neptune", "Earth", "Pluto"],
    correctAnswer: "Earth"
  },
  {
    question: "What is the largest organ inside the human body?",
    options: ["large intestine", "Liver", "small intestine", "lungs"],
    correctAnswer: "Liver"
  },
  {
    question: "What do you call a baby cow?",
    options: ["Calf", "calves", "kelvs", "cauli"],
    correctAnswer: "Calf"
  },
  {
    question: "What do you call a group of crows?",
    options: ["silent murder", "killer", "Silent killer", "Murder"],
    correctAnswer: "Murder"
  },
  {
    question: "In which year did the Titanic sink?",
    options: ["1911", "1912", "1913", "1914"],
    correctAnswer: "1912"
  },  
  ];

  let currentQuestion = 0;
  let score = 0;
  let timer;
  let timerInterval;
  
  function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }
  
  function initializeQuiz() {
    shuffle(questions);
    displayQuestion();
    startTimer();
    timerInterval = setInterval(updateTimer, 1000);
  }
  
  function startTimer() {
    timer = setTimeout(() => {
      alert("Time's up!");
      nextQuestion();
    }, 20000);
  }
  
  function resetTimer() {
    clearTimeout(timer);
    const timerElement = document.querySelector('.secstimer');
    timerElement.textContent = "20"; 
    startTimer();
  }
  
  
  function updateTimer() {
    const timerElement = document.querySelector('.secstimer');
    let seconds = parseInt(timerElement.textContent);
    if (seconds > 0) {
      seconds--;
      timerElement.textContent = seconds;
    }
  }
  
  function displayQuestion() {
    const questionElement = document.getElementById("question");
    const optionsElement = document.getElementById("options");
  
    questionElement.textContent = questions[currentQuestion].question;
  
    optionsElement.innerHTML = "";
    questions[currentQuestion].options.forEach((option) => {
      const button = document.createElement("button");
      button.textContent = option;
      button.classList.add("quiz-button");
  
      button.addEventListener("click", () => {
        checkAnswer(option);
        resetTimer();
      });
      
      optionsElement.appendChild(button);
    });
  }
  
  
  function checkAnswer(selectedAnswer) {
    const correctAnswer = questions[currentQuestion].correctAnswer;
  
    if (selectedAnswer === correctAnswer) {
      score++;
    } else{
      alert("Your answer is incorrect, correct answers will be shown once you finish this quiz");
    }
  
    document.getElementById("score").textContent = `Score: ${score}`;
    nextQuestion();
  }
  
  function openFile() {
    window.open('../../Trivias/Medium-Trivia (1)/AMB-Medium-T.html', '_blank');
  }
  
  
  function nextQuestion() {
    currentQuestion++;
  
    if (currentQuestion < questions.length) {
      displayQuestion();
      resetTimer();
    } else {
      clearInterval(timerInterval);
      clearTimeout(timer);
      alert(`Quiz completed! Your final score is ${score}`);
      openFile();
      
    }
  }