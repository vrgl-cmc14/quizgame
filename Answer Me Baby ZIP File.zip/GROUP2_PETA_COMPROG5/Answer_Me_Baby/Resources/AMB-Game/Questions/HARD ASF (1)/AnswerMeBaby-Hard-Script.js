let questions = [
  {
    question: "A period in European civilization immediately following the Middle ages and conventionally held to have been characterized by a surge of interest in classical scholarship and values.",
    options: ["Neoclassicism", "Classicism", "Renaissance Period", "Medieval Period"],
    correctAnswer: "Renaissance Period"
  },
  {
    question: "He was a Filipino catholic priest and was the first documented serial Killer in the Philippines",
    options: ["Macario Sakay", "Juan Severino Mallari", "Vicente Lim", "Catalina De Castro"],
    correctAnswer: "Juan Severino Mallari"
  },
  {
    question: "Was the first Chinese dynasty that ruled in the middle and lower Yellow river valley in China",
    options: ["Han Dynasty", "Ming Dynasty", "Xia Dynasty", "Shang Dynasty"],
    correctAnswer: "Shang Dynasty"
  },
  {
    question: "Who was the first black president in South Africa?",
    options: ["Nelson Mandela", "Jacob Zuma", "Cyril Ramaphosa", "Thabo Mbeki"],
    correctAnswer: "Nelson Mandela"
  },
  {
    question: "The Viking period started from what year?",
    options: ["790 CE", "791 CE", "793 CE", "792 CE"],
    correctAnswer: "793 CE"
  },
  {
    question: "What French sculpture created the Statue of Liberty",
    options: ["Auguste Rodin", "Frederic Auguste Barthoidi", "Antonine Bourdelle", "Camille Claudel"],
    correctAnswer: "Frederic Auguste Barthoidi"
  },
  {
    question: "How many words does Pablo Picasso's real name have",
    options: ["23", "24", "25", "26"],
    correctAnswer: "23"
  },
  {
    question: "Which country has the national dance 'Shota'?",
    options: ["Cape Verde", "Turkey", "Brazil", "Albania"],
    correctAnswer: "Albania"
  },
  {
    question: "Who was the 40th president of the United States of America",
    options: ["Barrack Obama", "Bill Clinton", "Ronald Reagan", "G.W. Bush"],
    correctAnswer: "Ronald Reagan"
  },
  {
    question: "How many New Zealand soldiers died in Gallipoli?",
    options: ["2449", "2559", "2669", "2779"],
    correctAnswer: "2779"
  },
  {
    question: "Banjul International Airport (Yundum International) is located in which country?",
    options: ["Bangladesh", "Gambia", "Pakistan", "India"],
    correctAnswer: "Gambia"
  },
  {
    question: "How many stars are on the national flag of USA?",
    options: ["48", "49", "50", "51"],
    correctAnswer: "50"
  },
  {
    question: "What was Ariana Grande's first UK number one single?",
    options: ["Into You", "Love Me Harder", "Break Free", "Problem"],
    correctAnswer: "Problem"
  },
  {
    question: "What year did Vincent Van Gogh die?",
    options: ["1870", "1880", "1890", "1900"],
    correctAnswer: "1890"
  },
  {
    question: "What is the formula for a Quadratic Equation?",
    options: ["-b +- sqrt(((b)^2 - 4ac)/2a)", "mx + b", "ax^2 + bx + c ", "x2 - x1 / y2 - y1"],
    correctAnswer: "-b +- sqrt(((b)^2 - 4ac)/2a)"
  },
  {
    question: "What are called those angles that sum up to 180 degrees?",
    options: ["Supplementary Angles", "Central Angle", "Inscribed Angle", "Angle’s Burge"],
    correctAnswer: "Supplementary Angles"
  },
  {
    question: "What is the process by which a cell engulfs a solid particle to form an internal vesicle known as a phagosome?",
    options: ["Exocytosis", "Pinocytosis", "Phagocytosis", "Endocytosis"],
    correctAnswer: "Phagocytosis"
  },
  {
    question: "A powerful mathematical toolbox for dealing with phenomena in a state of flux, from the flow of water to the expansion of the cosmos.",
    options: ["Algebra", "Arithmetic", "Geometry", "Calculus"],
    correctAnswer: "Calculus"
  },
  {
    question: "What if you divide 352 by 12?",
    options: ["23.9", "29.3", "27.9", "67.8"],
    correctAnswer: "29.3"
  },
  {
    question: "C=2πr is the formula for?",
    options: ["Circumference of a triangle", "Area of a circle", "Circumference of a circle", "Perimeter of a circle"],
    correctAnswer: "Circumference of a circle"
  },
  {
    question: "The area of a Triangle is",
    options: ["B+h", "Bxhx2", "b/h", "bh/2"],
    correctAnswer: "bh/2"
  },
  {
    question: "Cosec θ",
    options: ["1+sin θ", "1/sec θ", "1/sin θ", "2/sin θ"],
    correctAnswer: "1/sin θ"
  },
  {
    question: "What is the largest species of a Penguin?",
    options: ["Gentoo", "King", "Chinstrap", "Emperor"],
    correctAnswer: "Emperor"
  },
  {
    question: "What Is The Only Planet That Spins Clockwise?",
    options: ["Mercury", "Venus", "Jupiter", "Neptune"],
    correctAnswer: "Venus"
  },
  {
    question: "How Often Does Halley’s Comet Appear In The Sky?",
    options: ["75-76 years", "76-77 years", "77-78 years", "78-79 years"],
    correctAnswer: "75-76 years"
  },
  {
    question: "How Many Planets In Our Solar System Have Moons?",
    options: ["5", "6", "7", "8"],
    correctAnswer: ""
  },
  {
    question: "In Science, How Long Is An Eon?",
    options: ["100,000", "1,000,000", "1,000,000,000", "1,000,000,000,000"],
    correctAnswer: "1,000,000,000"
  },
  {
    question: "The Brain Is Divided Into How Many Lobes?",
    options: ["1", "2", "3", "4"],
    correctAnswer: "4"
  },
  {
    question: "The Oldest Living Tree Is 4,843 Years Old And Can Be Found Where?",
    options: ["Arizona", "Minnesota", "California", "Dallas"],
    correctAnswer: "California"
  },
  {
    question: "How Many Electrons Does A Hydrogen Atom Have?",
    options: ["0", "1", "2", "3"],
    correctAnswer: "1"
  },

];

let currentQuestion = 0;
let score = 0;
let timer;
let timerInterval;

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function initializeQuiz() {
  shuffle(questions);
  displayQuestion();
  startTimer();
  timerInterval = setInterval(updateTimer, 1000);
}

function startTimer() {
  timer = setTimeout(() => {
    alert("Time's up!");
    nextQuestion();
  }, 20000);
}

function resetTimer() {
  clearTimeout(timer);
  const timerElement = document.querySelector('.secstimer');
  timerElement.textContent = "20"; 
  startTimer();
}


function updateTimer() {
  const timerElement = document.querySelector('.secstimer');
  let seconds = parseInt(timerElement.textContent);
  if (seconds > 0) {
    seconds--;
    timerElement.textContent = seconds;
  }
}

function displayQuestion() {
  const questionElement = document.getElementById("question");
  const optionsElement = document.getElementById("options");

  questionElement.textContent = questions[currentQuestion].question;

  optionsElement.innerHTML = "";
  questions[currentQuestion].options.forEach((option) => {
    const button = document.createElement("button");
    button.textContent = option;
    button.classList.add("quiz-button");

    button.addEventListener("click", () => {
      checkAnswer(option);
      resetTimer();
    });
    
    optionsElement.appendChild(button);
  });
}


function checkAnswer(selectedAnswer) {
  const correctAnswer = questions[currentQuestion].correctAnswer;

  if (selectedAnswer === correctAnswer) {
    score++;
  } else{
    alert("Your answer is incorrect, correct answers will be shown once you finish this quiz");
  }

  document.getElementById("score").textContent = `Score: ${score}`;
  nextQuestion();
}

function openFile() {
  window.open('../../Trivias/HARD T/AMB-Hard-T.html', '_blank');
}


function nextQuestion() {
  currentQuestion++;

  if (currentQuestion < questions.length) {
    displayQuestion();
    resetTimer();
  } else {
    clearInterval(timerInterval);
    clearTimeout(timer);
    alert(`Quiz completed! Your final score is ${score}`);
    openFile();
    
  }
}