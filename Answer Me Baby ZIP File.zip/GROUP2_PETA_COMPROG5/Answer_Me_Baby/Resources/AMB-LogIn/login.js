var maxAttempts = 3;

function login(event) {
    event.preventDefault();
    var uid = document.getElementById("UID").value.trim();
    var pass = document.getElementById("pass").value.trim();
    var defuid = "yoochungah";
    var defpass = "baesuzy";

    if (uid === defuid && pass === defpass) {
        window.location.href = '../AMB-LoadingScreen/AnswerMeBabyLoading.html';
    } else {
        maxAttempts--;
        alert("Username or password is incorrect, please try again later. \n " + maxAttempts +" attempts left");
        

        var attemptsLeft = maxAttempts + " attempts left";
        document.getElementById("attempts").innerHTML = attemptsLeft;

        if (maxAttempts === 0) {
            document.getElementById("attempts").innerHTML = "Max attempts reached. Please wait 60 seconds.";
            document.getElementById('submit').setAttribute('disabled', 'true');
            timer();
        }
    }
}

function timer() {
    let seconds = 60;

    const timerInterval = setInterval(() => {
        if (seconds > 0) {
            document.getElementById("attempts").innerHTML = `Time remaining: ${seconds} seconds`;
            seconds--;
        } else {
            clearInterval(timerInterval);
            location.reload();
        }
    }, 1000);
}
