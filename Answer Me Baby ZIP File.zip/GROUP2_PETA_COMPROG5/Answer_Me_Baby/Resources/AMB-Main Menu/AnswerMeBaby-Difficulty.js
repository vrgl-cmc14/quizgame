function bukasE(){
    window.location.href = '../AMB-Game/Questions/AMB-Easy/AnswerMeBaby-Questions-Easy.html';
}
function bukasM(){
    window.location.href = '../AMB-Game/Questions/AMB-Medium (1)/AnswerMeBaby-Questions-Medium.html';
}
function bukasH(){
    window.location.href = '../AMB-Game/Questions/HARD ASF (1)/answerMeBaby-Questions-Hard.html';
}